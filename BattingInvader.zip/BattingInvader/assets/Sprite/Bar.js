cc.Class({
    extends: cc.Component,

    properties: {
        //最大移動スピード
        maxMoveSpeed: 0,
        //加速度
        accel:0,
    },

    // use this for initialization
    onLoad: function () {
        
        //加速方向フラグ
        this.accLeft = false;
        this.accRight = false;
        //スピードの初期化
        this.xSpeed = 0;
        //キーボードイベントリスナーの初期化
        this.setInputControl();
    },
        setInputControl: function () {
        var self = this;
        // キーボードイベントリスナー追加
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            // キーが押された時に呼ばれ、加速を開始する
            onKeyPressed: function(keyCode, event) {
                switch(keyCode) {
                    case cc.KEY.a:
                        self.accLeft = true;
                        self.accRight = false;
                        break;
                    case cc.KEY.d:
                        self.accLeft = false;
                        self.accRight = true;
                        break;
                        
                }
            },
            // キーが離された時に呼ばれ、加速を停止する
            onKeyReleased: function(keyCode, event) {
                switch(keyCode) {
                    case cc.KEY.a:
                        self.accLeft = false;
                        break;
                    case cc.KEY.d:
                        self.accRight = false;
                        break;
                    
                }
            }
        }, self.node);
    },

    update: function (dt) {
        // 加速方向に従ってスピードを更新する
        if (this.accLeft) {
            this.xSpeed -= this.accel * dt;
        } else if (this.accRight) {
            this.xSpeed += this.accel * dt;
        }
        //キーを離したときピタッと止まる
        if(! this.accLeft&&! this.accRight){
            this.xSpeed = 0;
        }
        // 最大スピードの制限
        if ( Math.abs(this.xSpeed) > this.maxMoveSpeed ) {
            // 最大スピードを超えないように設定
            this.xSpeed = this.maxMoveSpeed * this.xSpeed / Math.abs(this.xSpeed);
        }

        // プレイヤーの位置更新
        this.node.x += this.xSpeed * dt;
    },
});
