cc.Class({
    extends: cc.Component,

    properties: {
        shotprefab:{
            default: null,
            type:cc.Prefab
        }
    },

    // use this for initialization
    onLoad: function () {
        //タイム初期化
        this.time = 0;
    },

    // called every frame, uncomment this function to activate update callback
    update: function (dt) {
        this.time += dt;
        if(this.time > 2){
            var shot = cc.instantiate(this.shotprefab);
            this.node.addChild(shot);
            this.time = 0;
        }
        
    },
});
