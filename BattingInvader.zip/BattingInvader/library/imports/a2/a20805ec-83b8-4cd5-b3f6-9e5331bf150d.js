cc.Class({
    "extends": cc.Component,

    properties: {
        //弾の速度
        ySpeed: 0
    },

    // use this for initialization
    onLoad: function onLoad() {},

    update: function update(dt) {
        this.node.y -= this.ySpeed * dt;
    }
});