"use strict";
cc._RFpush(module, 'a2080Xsg7hM1bP2nlMxvxUN', 'Shot1');
// Sprite\Shot1.js

cc.Class({
    "extends": cc.Component,

    properties: {
        //弾の速度
        ySpeed: 0
    },

    // use this for initialization
    onLoad: function onLoad() {},

    update: function update(dt) {
        this.node.y -= this.ySpeed * dt;
    }
});

cc._RFpop();